from django.shortcuts import render, redirect
from .models import Post
from .forms import PostForm
from django.contrib import messages #메세지 출력
from django.core.paginator import Paginator # 페이지 하단
from .visualization import Visualization
from django.views.decorators.clickjacking import xframe_options_sameorigin

# Create your views here.

def helloworld(request):
  return render(request, 'myApp/helloworld.html')

def post_list(request):
  all_posts = Post.objects.all().order_by('-create_date')
  paginator = Paginator(all_posts,3)
  page = request.GET.get('page')
  posts = paginator.get_page(page)

  return render(request,'myApp/post_list.html',{
      'posts':posts
  })

def create_post(request):
  return render(request, 'myApp/create_post.html')

def create_post(request):
  if request.method == 'POST':
    form = PostForm(request.POST)
    if form.is_valid():
        form.instance.user = request.user
        form.save()
    return redirect('/')
  else:
    if not request.user.is_authenticated:
        messages.info(request,'로그인이 필요합니다.')
        return redirect('sign_in')
    form = PostForm()

  return render(request, 'myApp/create_post.html', {
    'form':form
  })

def post_detail(request, pk):
	post = Post.objects.get(pk=pk)
	return render(request, 'myApp/post_detail.html', {
'post':post,
})


def post_edit(request, pk):
    post = Post.objects.get(pk=pk)

    if not request.user.is_authenticated:
        messages.info(request, '로그인이 필요합니다.')
        return redirect('sign_in')

    if post.user != request.user:
        messages.info(request, '권한이 없습니다.')
        return redirect('/')

    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            messages.info(request, '글이 수정되었습니다.')
            return redirect('/')
    else:
        form = PostForm(instance=post)

    return render(request, 'myApp/create_post.html',{
        'form':form
    })

def post_remove(request, pk):
    post = Post.objects.get(pk=pk)

    if not request.user.is_authenticated:
        messages.info(request, '로그인이 필요합니다.')
        return redirect('sign_in')

    if post.user != request.user:
        messages.info(request, '권한이 없습니다.')
        return redirect('/')

    post.delete()
    messages.info(request, '글을 삭제하였습니다.')
    return redirect('/')

def my_page(request):
    if not request.user.is_authenticated:
        messages.info(request, '로그인이 필요합니다.')
        return redirect('sign_in')

    posts = Post.objects.all().order_by('-create_date')

    return render(request,'myApp/my_page.html',{
        'posts': posts
    })
#{% if user.is_authenticated %}

def visualization_service(request):

    return render(request, 'myApp/visualization_service.html',{

    })

# @마크는 ifram노드를 허락하는 옵션
@xframe_options_sameorigin
def map_view(request):
    if not request.user.is_authenticated:
        messages.info(request, '로그인이 필요합니다.')
        return redirect('sign_in')

    area = request.GET.get('area')

    figure = Visualization().get_figure(area)
    return render(request, 'myApp/map_view.html',{
        'figure':figure,
    })
